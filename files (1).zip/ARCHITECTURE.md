# System Architecture

## High-Level Data Flow

```mermaid
flowchart LR
    subgraph Field["🌾 Field Layer"]
        F["👨‍🌾 Farmer"]
        IOT["📡 IoT Sensors"]
        SAT["🛰️ Satellite Feed"]
        WX["🌦️ Weather APIs"]
    end

    subgraph App["📱 Application Layer"]
        MA["Mobile / Web App"]
    end

    subgraph Cloud["☁️ Cloud Layer"]
        API["Cloud API (Python + Node.js)"]
        DB["Cloud Database\n(storage & real-time data)"]
        AI["AI Model\nCNN-based disease classification"]
    end

    subgraph Output["💡 Output Layer"]
        PRED["Prediction Engine"]
        ADV["Personalized Advisory"]
    end

    F -->|Photo / query| MA
    IOT --> API
    SAT --> API
    WX --> API
    MA --> API
    API --> DB
    API --> AI
    AI --> PRED
    PRED --> ADV
    ADV --> MA
    MA --> F
```

## Component Breakdown

### 1. Field Layer
- **Farmer** — primary user; captures crop images and receives advisories through the app.
- **IoT Sensors** — distributed field nodes feeding soil/moisture/environmental data.
- **Satellite Feed** — remote sensing data for farm-level visibility beyond ground sensors.
- **Weather APIs** (e.g. OpenWeatherMap) — historical and forecast weather data, a key predictive signal for pest/disease risk.

### 2. Application Layer
- **Mobile / Web App** — farmer-facing interface (HTML/CSS/JavaScript), designed offline-first so core functions remain usable in low-connectivity rural areas.

### 3. Cloud Layer
- **Cloud API** — Python + Node.js services handling ingestion, orchestration, and model serving.
- **Cloud Database** — stores historical data, sensor streams, and user data for both real-time queries and model retraining.
- **AI Model** — CNN-based image classifier for crop disease identification, combined with weather-pattern analysis for forward-looking risk scoring. Optimized as TensorFlow Lite models for edge/mobile inference.

### 4. Output Layer
- **Prediction Engine** — fuses image classification output with weather/IoT/satellite risk signals to produce a forecast (pest/disease, crop, time window).
- **Personalized Advisory** — translates the prediction into a location-specific, crop-stage-based recommendation, including precision pesticide guidance, delivered back to the farmer.

## Design Principles

1. **Offline-first** — the app should degrade gracefully without connectivity, not fail outright, given rural network constraints.
2. **Multi-modal fusion over single-signal detection** — image data alone only tells you what's already wrong; weather + IoT + satellite data is what makes *forecasting* (vs. diagnosis) possible.
3. **Precision over blanket action** — every output is scoped to a specific location and crop growth stage, aimed at reducing unnecessary pesticide use.
4. **Validated, not just modeled** — predictions are designed to be checked against expert-verified data to control false-positive rates before farmers act on them.

## Tech Stack Summary

| Layer | Technology |
|---|---|
| AI/ML | CNN (crop disease classification), TensorFlow Lite (edge inference) |
| Backend | Python, Node.js |
| Database | Cloud database (real-time + historical storage) |
| Data Sources | Weather APIs, IoT sensor network, satellite APIs |
| Frontend | HTML, CSS, JavaScript |
